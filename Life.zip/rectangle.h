#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <QColor>
#include <QGraphicsItem>


class Rectangle : public QObject, public QGraphicsItem {

    // this makes it so that we can emit signals
    Q_OBJECT

public:
    Rectangle(QColor color, const int display_x, const int display_y, const int x, const int y);  // constructor
    Rectangle(const int display_x, const int display_y, int height);
    int get_x() const { return x_; }  // inline member function
    int get_y() const { return y_; }  // inline member function
    int get_display_x()  const { return display_x_; }  // inline member function
    int get_display_y()  const { return display_y_; }  // inline member function
    QColor get_color() const {return color_;} // return color
    void set_color(QColor c);
    int get_height(){ return height_; }
    void set_display_x(int x)  { display_x_ = x; }  // inline member function
    void set_display_y(int y)  { display_y_ = y; }  // inline member function
    void set_height(int height) { height_ = height; }

    QRectF boundingRect() const override;
    QPainterPath shape() const override;

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;

    static int get_width() { return width_; }

signals:
    void revive(Rectangle* cell);
    void death(Rectangle* cell);


private:
  int x_;
  int y_;
  int display_x_;
  int display_y_;
  QColor color_;
  int height_ = 15;


  static const int width_ = 15; // the size of the square
  friend bool operator==(const Rectangle &first, const Rectangle &other);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

};
#endif
