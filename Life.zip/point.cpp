#include "point.h"
#include <QtDebug>

Point::Point(int const x, int const y){
    this->x_ = x;
    this->y_ = y;
}

void Point::display_point(){
    qDebug() << this->x_  << " " << this->y_;
}
