#include "gamewindow.h"
#include "ui_gamewindow.h"

#include <QDebug>
#include <QTime>
#include <QTimer>
// 11 7


gameWindow::gameWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::gameWindow) {

    ui->setupUi(this);
    qsrand(static_cast<unsigned>(QTime::currentTime().msec()));
    this->alive = 0;
    this->population = 405;
    this->turn = 0;
    this->speed = 1;
    this->x_bound = 27;
    this->y_bound = 15;
    this->keep_playing_ = false;
    this->max_graph_ = 27;
    this->start_x_graph = 40;
    this->y_graph_ = 60 + (16 * 14.5) + 125;
    this->is_playing = false;

    // used to adjust the spped of the timer
    ui->speedSlider->setMinimum(1);
    ui->speedSlider->setMaximum(5);
    ui->speedSlider->setTickInterval(1);



    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &gameWindow::play);
//    connect(timer, &QTimer::timeout, this, &gameWindow::on_speedSlider_valueChanged);
    connect(ui->playButton, &QAbstractButton::clicked, this, &gameWindow::autoRunSlot);
    connect(ui->stepButton, &QAbstractButton::clicked, this, &gameWindow::play);
    connect(ui->pauseButton,  &QAbstractButton::clicked, this, &gameWindow::stopSlot);
//    connect(ui->speedSlider, &gameWindow::getSpeed, this, &gameWindow::autoRunSlot);

//    ui->gameGraphicsView->setForegroundBrush(Qt::white);

// use value changed


    // the QGraphicsView is the UI element that contains the
    // scene that we will actually get to draw on.
    QGraphicsView * view = ui->gameGraphicsView;

    // scene is a QGraphicsScene pointer field of the PlotWindow class
    // this makes our lives easier by letting us easily access it
    // from other functions in this class.
    scene = new QGraphicsScene;

    ui->gameGraphicsView->setScene(scene);
    ui->gameGraphicsView->setBackgroundBrush(QBrush(Qt::white, Qt::SolidPattern));

    view->setScene(scene);

    // make the scene the same size as the view containing it
    view->setSceneRect(0,0,view->frameSize().width(),view->frameSize().height());


    //keeps track of each cell
    //creates the playing field
    createPlayField(40, 60, playingField);

    //Intalizes the population label
    std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
    QString qs(p.c_str());
    ui->populationLabel->setText(qs);

    // creates the graph

    QGraphicsRectItem* rect = new QGraphicsRectItem();
//    QGraphicsRectItem* a = new QGraphicsRectItem();

    rect->setRect(40, 60 + (16 * 14.5), 15 * 27, 125);
//    a->setRect(40 + (15* 27), 60 + (16 * 14.5) + 125, 15, -125);

    scene->addItem(rect);
//    scene->addItem(a);

}


void gameWindow::createPlayField(int width, int height, Rectangle* playingField[][27]){
    int start_y = height;
    int start_x = width;
    // creates the playing field
    for(int y = 0; y < 15; ++y){
        for(int x = 0; x < 27; ++x){
            QColor is_alive = Qt::white;
            // detemine if the cell is alive or dead
            if(qrand() % 2){
                is_alive = QColor(220, 50, 150, 100);
                this->alive++;
            }
            Rectangle* r = new Rectangle(is_alive, start_x, start_y, x, y);
            connect(r, &Rectangle::revive, this, &gameWindow::reviveSlot);
            connect(r, &Rectangle::death, this, &gameWindow::deathSlot);
            playingField[y][x] = r;
            scene->addItem(r);
            start_x += Rectangle::get_width();
        }
        start_x = width;
        start_y += Rectangle::get_width();
    }
    plotGraph();
}


std::vector<Point*> gameWindow::checkNeighbors(Rectangle* r){
    int x = r->get_x();
    int y = r->get_y();
    int pos_x;
    int pos_y;
    std::vector<Point*> neighbors;
//    if(x - 1 >= 0){
//        Point* p = new Point(x-1, y);
//        neighbors.push_back(p);
//    }
//    if(x + 1 < 27){
//        Point *p = new Point(x + 1, y);
//        neighbors.push_back(p);
//    }
//    if(y - 1 >= 0){
//        Point *p = new Point(x, y - 1);
//        neighbors.push_back(p);
//    }
//    if(y + 1 < 15){
//        Point *p = new Point(x, y + 1);
//        neighbors.push_back(p);
//    }
//    if(x + 1 < 27 && y + 1 < 15){
//        Point *p = new Point(x + 1, y + 1);
//        neighbors.push_back(p);
//    }
//    if(x + 1 < 27 && y - 1 >= 0){
//        Point *p = new Point(x + 1, y - 1);
//        neighbors.push_back(p);
//    }
//    if(x - 1 >= 0 && y + 1 < 15){
//        Point *p = new Point(x - 1, y + 1);
//        neighbors.push_back(p);
//    }
//    if(x - 1 >= 0 && y - 1 >= 0){
//        Point *p = new Point(x - 1, y - 1);
//        neighbors.push_back(p);
//    }
    for(int i = -1; i < 2; ++i){
        for(int j = -1; j < 2; ++j){
            pos_x = (x + i + this->x_bound) % this->x_bound;
            pos_y = (y + j + this->y_bound) % this->y_bound;
            if(!(pos_x == x && pos_y == y)){
                Point *p = new Point(pos_x, pos_y);
                neighbors.push_back(p);
            }
        }
    }
    return neighbors;
}


void gameWindow::determine_cell(Rectangle* r, int alive){
    QColor c;
    if((alive > 3 || alive < 2) && (r->get_color() == QColor(220, 50, 150, 100))){
        c = Qt::white;
//        r->set_color(Qt::white);
        this->alive--;
    } else  if((alive == 3) && (r->get_color() == Qt::white)){
        c = QColor(220, 50, 150, 100);
//        r->set_color(QColor(220, 50, 150, 100));
        this->alive++;
    } else{
        c = r->get_color();
    }
    Rectangle* rec = new Rectangle(c, r->get_display_x(), r->get_display_y(), r->get_x(), r->get_y());
    connect(rec, &Rectangle::revive, this, &gameWindow::reviveSlot);
    connect(rec, &Rectangle::death, this, &gameWindow::deathSlot);
    next[r->get_y()][r->get_x()] = rec;
}


int gameWindow::get_neighbors(std::vector<Point*> neighbors){
    int alive = 0;
    for(Point* n : neighbors){
        if(this->playingField[n->get_y()][n->get_x()]->get_color() == QColor(220, 50, 150, 100)){
            alive++;
        }
    }
    return alive;
}


void gameWindow::free_neighbors(std::vector<Point*> neighbors){
    for(Point* n : neighbors){
        free(n);
    }
}

void gameWindow::play(){
    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            std::vector<Point*> neighbors = checkNeighbors(this->playingField[y][x]);
            int alive = get_neighbors(neighbors);
            determine_cell(this->playingField[y][x], alive);
            free_neighbors(neighbors);
        }
    }
    renderPlayField();

    turn++;

    std::string t = "Turn: " + std::to_string(turn);
    QString qs(t.c_str());
    ui->turnLabel->setText(qs);

    std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
    QString ps(p.c_str());
    ui->populationLabel->setText(ps);

    plotGraph();

}

void gameWindow::on_speedSlider_valueChanged(int value) {
    this->speed = 1.0/value;
    std::string as_str = std::to_string(this->speed);
    ui->speedLabel->setText(QString(("Speed: " + as_str).c_str()));
}

void gameWindow::on_speedSlider_sliderReleased() {
    if(is_playing){
        autoRunSlot();
    }
}


void gameWindow::autoRunSlot(){
    is_playing = true;
    timer->start(this->speed * 1000);

}

void gameWindow::stopSlot(){
    timer->stop();
}

void gameWindow::renderPlayField(){
    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            Rectangle *r = this->playingField[y][x];
            scene->removeItem(r);
            free(r);
            scene->addItem(next[y][x]);
            this->playingField[y][x] = next[y][x];
        }
    }
    update();
}


void gameWindow::deathSlot(Rectangle* cell){
    if(cell->get_color() == QColor(220, 50, 150, 100)){
            cell->set_color(Qt::white);
            alive--;
            update();
            std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
            QString ps(p.c_str());
            ui->populationLabel->setText(ps);
        }
}

void gameWindow::reviveSlot(Rectangle* cell){
    if(cell->get_color() == Qt::white){
        cell->set_color(QColor(220, 50, 150, 100));
        alive++;
        update();
        std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
        QString ps(p.c_str());
        ui->populationLabel->setText(ps);
    }

}

void gameWindow::plotGraph(){
    if(graphs.size()){
        for(Rectangle* r : graphs){
            scene->removeItem(r);
        }
    }
    scene->update();

    if(graphs.size() == 27){

        free(graphs[0]);

        graphs.erase(graphs.begin());

        this->start_x_graph -= (graphs[0]->get_width());

        for(Rectangle* r : graphs){

            r->set_display_x(r->get_display_x() - r->get_width());
        }

    }

    Rectangle* r = new Rectangle(this->start_x_graph, this->y_graph_, double(-125.0 * (this->alive/this->population)));

    this->graphs.push_back(r);

    for(Rectangle* r : graphs){
        scene->addItem(r);
    }

    this->start_x_graph += r->get_width();
}



void gameWindow::on_reset_clicked() {
    reset_graph();
    this->alive = 0;
    this->turn = 0;

    QColor is_alive;
    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            int t = qrand() % 2;
            if(t){
                is_alive = QColor(220, 50, 150, 100);
                this->alive++;
            } else {
                is_alive = Qt::white;
            }
            this->playingField[y][x]->set_color(is_alive);
        }
    }


    scene->update();

    std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
    QString qs(p.c_str());
    ui->populationLabel->setText(qs);
    std::string t = "Turn: " + std::to_string(turn);
    QString ts(t.c_str());
    ui->turnLabel->setText(ts);

    plotGraph();

}

void gameWindow::on_clear_clicked(){
    this->alive = 0;
    this->turn = 0;
    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            this->playingField[y][x]->set_color(Qt::white);
            scene->removeItem(this->playingField[y][x]);
        }
    }

    scene->update();

    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            scene->addItem(this->playingField[y][x]);
        }
    }

    reset_graph();


    std::string p = "Population " + std::to_string(int(this->alive)) + " (" + std::to_string(int((this->alive/this->population)* 100)) + "%)";
    QString qs(p.c_str());
    ui->populationLabel->setText(qs);
    std::string t = "Turn: " + std::to_string(turn);
    QString ts(t.c_str());
    ui->turnLabel->setText(ts);

    plotGraph();
}

void gameWindow::reset_graph(){
    for(Rectangle* r : graphs){
        scene->removeItem(r);
    }

    while(graphs.size() > 0){
        free(graphs[0]);
        graphs.erase(graphs.begin());
    }
    this->start_x_graph = 40;

}

void gameWindow::on_shape_input_returnPressed(){
    qDebug() << ui->shape_input->text();
    QString text = ui->shape_input->text();
    std::string choice = text.toStdString();
    choice.c_str();

//    Rectangle* center = this->playingField[11][7];

    if(choice == "still lifes"){
        this->playingField[9][7]->set_color(Qt::white);
        this->playingField[8][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[10][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[9][6]->set_color(QColor(220, 50, 150, 100));
        this->playingField[9][8]->set_color(QColor(220, 50, 150, 100));

        this->playingField[7][5]->set_color(Qt::white);
        this->playingField[7][6]->set_color(Qt::white);
        this->playingField[7][7]->set_color(Qt::white);
        this->playingField[7][8]->set_color(Qt::white);
        this->playingField[7][9]->set_color(Qt::white);

        this->playingField[8][9]->set_color(Qt::white);
        this->playingField[9][9]->set_color(Qt::white);
        this->playingField[10][9]->set_color(Qt::white);
        this->playingField[11][9]->set_color(Qt::white);
        this->playingField[11][5]->set_color(Qt::white);
        this->playingField[11][6]->set_color(Qt::white);
        this->playingField[11][7]->set_color(Qt::white);
        this->playingField[11][8]->set_color(Qt::white);
        this->playingField[10][8]->set_color(Qt::white);

        this->playingField[10][5]->set_color(Qt::white);
        this->playingField[9][5]->set_color(Qt::white);
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[10][6]->set_color(Qt::white);
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[8][8]->set_color(Qt::white);
        this->playingField[8][6]->set_color(Qt::white);

    } else if(choice == "oscillators"){
        this->playingField[9][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[8][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[10][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[9][6]->set_color(Qt::white);
        this->playingField[9][8]->set_color(Qt::white);

        this->playingField[7][5]->set_color(Qt::white);
        this->playingField[7][6]->set_color(Qt::white);
        this->playingField[7][7]->set_color(Qt::white);
        this->playingField[7][8]->set_color(Qt::white);
        this->playingField[7][9]->set_color(Qt::white);

        this->playingField[8][9]->set_color(Qt::white);
        this->playingField[9][9]->set_color(Qt::white);
        this->playingField[10][9]->set_color(Qt::white);
        this->playingField[11][9]->set_color(Qt::white);
        this->playingField[11][5]->set_color(Qt::white);
        this->playingField[11][6]->set_color(Qt::white);
        this->playingField[11][7]->set_color(Qt::white);
        this->playingField[11][8]->set_color(Qt::white);
        this->playingField[10][8]->set_color(Qt::white);

        this->playingField[10][5]->set_color(Qt::white);
        this->playingField[9][5]->set_color(Qt::white);
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[10][6]->set_color(Qt::white);
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[8][8]->set_color(Qt::white);
        this->playingField[8][6]->set_color(Qt::white);
    } else if(choice == "spaceships"){
        this->playingField[9][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[8][7]->set_color(Qt::white);
        this->playingField[10][7]->set_color(Qt::white);
        this->playingField[9][6]->set_color(Qt::white);
        this->playingField[9][8]->set_color(Qt::white);

        this->playingField[7][5]->set_color(Qt::white);
        this->playingField[7][6]->set_color(Qt::white);
        this->playingField[7][7]->set_color(Qt::white);
        this->playingField[7][8]->set_color(Qt::white);
        this->playingField[7][9]->set_color(Qt::white);

        this->playingField[8][9]->set_color(Qt::white);
        this->playingField[9][9]->set_color(Qt::white);
        this->playingField[10][9]->set_color(Qt::white);
        this->playingField[11][9]->set_color(Qt::white);
        this->playingField[11][5]->set_color(Qt::white);
        this->playingField[11][6]->set_color(QColor(220, 50, 150, 100));
        this->playingField[11][7]->set_color(QColor(220, 50, 150, 100));
        this->playingField[11][8]->set_color(QColor(220, 50, 150, 100));
        this->playingField[10][8]->set_color(Qt::white);

        this->playingField[10][5]->set_color(Qt::white);
        this->playingField[9][5]->set_color(Qt::white);
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[10][6]->set_color(QColor(220, 50, 150, 100));
        this->playingField[8][5]->set_color(Qt::white);
        this->playingField[8][8]->set_color(Qt::white);
        this->playingField[8][6]->set_color(Qt::white);
    } else{
        // pop up
    }


}



gameWindow::~gameWindow()
{
    for(int y = 0; y < this->y_bound; ++y){
        for(int x = 0; x < this->x_bound; ++x){
            free(this->playingField[y][x]);
            free(this->next[y][x]);
        }
    }
//    for(Rectangle* r : this->graphs){
//        free(r);
//    }
    free(timer);

    delete ui;
}










