#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iostream>
#include <QtWidgets>


#include "rectangle.h"

/**
  Creates a new Point object with coordinates x and y
  @param x int x coordinate
  @param y int y coordinate
*/
Rectangle::Rectangle(QColor color, const int display_x, const int display_y, const int x, const int y) {
  this->color_ = color;
//    int display_x_;
//    int display_y_;
  display_x_ = display_x;
  display_y_ = display_y;

  x_ = x;
  y_ = y;

}

Rectangle::Rectangle(const int display_x, const int display_y, int height){
    this->color_ = Qt::white;
    this->display_x_ = display_x;
    this->display_y_ = display_y;
    this->height_ = height;
}

void Rectangle::set_color(QColor c){
    this->color_ = c;
    update();
}
// where is this object located
// always a rectangle, Qt uses this to know "where" the user
// would be interacting with this object
QRectF Rectangle::boundingRect() const
{
    return QRectF(display_x_, display_y_, width_, height_);
}

// define the actual shape of the object
QPainterPath Rectangle::shape() const
{
    QPainterPath path;
    path.addRect(display_x_, display_y_, width_, height_);

    return path;
}

// called by Qt to actually display the point
void Rectangle::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);


    QBrush b = painter->brush();
    // update the line for setBrush to be this
    painter->setBrush(QBrush(color_));
    QPen pen(Qt::black, 1);
    painter->setPen(pen);
    painter->drawRect(QRect(this->display_x_, this->display_y_, this->width_, this->height_));
    painter->setBrush(b);
}

void Rectangle::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if(event->button() == Qt::RightButton){
        emit death(this);
    }
    if(event->button() == Qt::LeftButton){
        emit revive(this);
    }
}


/**
  Makes it so the == operator will have the behavior that you
  expect when comparing points.
  You can overload pretty much any operator in c++
  @param first Point left hand side of the expression
  @param other Point right hand side of the expression
*/

bool operator==(const Rectangle &first, const Rectangle &other) {
  return first.x_ == other.x_ && first.y_ == other.y_;
}
