#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <vector>

#include "rectangle.h"
#include "point.h"

QT_BEGIN_NAMESPACE
namespace Ui { class gameWindow; }
QT_END_NAMESPACE

class gameWindow : public QMainWindow
{
    Q_OBJECT

public:
    gameWindow(QWidget *parent = nullptr);

    void createPlayField(int width, int height, Rectangle* playingField[][27]);
    std::vector<Point*> checkNeighbors(Rectangle* r);
    void free_neighbors(std::vector<Point*> neighbors);
    int get_neighbors(std::vector<Point*> neighbors);
    void determine_cell(Rectangle* r, int alive);
    void renderPlayField();
    void plotGraph();
    void updateGraph();
    void addBars();
    void clearBars();
    void reset_graph();
    ~gameWindow();



private:
    Ui::gameWindow *ui;
    QGraphicsScene *scene;
    double alive;
    double population;
    int x_bound;
    int y_bound;
    Rectangle* playingField[15][27];
    Rectangle* next[15][27];
    int turn;
    double speed;
    QTimer* timer;
    bool keep_playing_;
    int max_graph_;
    int start_x_graph;
    int y_graph_;
    int graph_num = 0;
    std::vector<Rectangle*> graphs;
    bool is_playing;

//    std::vector<QGraphicsRectItem*> graphs;


private slots:
    void play();
    void on_speedSlider_valueChanged(int value);
    void autoRunSlot();
    void stopSlot();
    void reviveSlot(Rectangle* cell);
    void deathSlot(Rectangle* cell);
    void on_speedSlider_sliderReleased();
    void on_reset_clicked();
    void on_clear_clicked();

    void on_shape_input_returnPressed();

signals:
    void getSpeed();



};
#endif // GAMEWINDOW_H
