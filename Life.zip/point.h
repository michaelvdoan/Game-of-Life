#ifndef POINT_H
#define POINT_H

#include <QObject>

class Point: public QObject{
    private:
        int x_;
        int y_;
    public:
        Point(const int x, const int y);
        int get_x() const { return x_; }
        int get_y() const { return y_; }
        void display_point();
};

#endif
